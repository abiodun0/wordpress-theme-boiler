       </div>

</section>

        <footer id="footer" role="contentinfo">  

             <div class="container">                
                <div class="row">  

                  <?php if ( is_active_sidebar( 'footer-bar' ) ) dynamic_sidebar('footer-bar');?>   

             </div>
            </div>       
            <!--div class="container">                
                <div class="row">                    
                    <div class="col-md-4">
                        <h4 class="font-alt mt0">About Us</h4>
                        <p>Meed Networks is a multi-faceted Information Technology company with a strong focus on using technology to improve operational efficiencies in businesses and institutions of all sizes.</p>
                        <p></p>
                        <a data-nav href="#about" class="text-primary">Learn More</a>
                    </div>
                    
                    <div class="col-md-4">
                        <h4 class="font-alt mt0">Address</h4>
                        <address>
                            34 Burundi Street<br>
                            Off Damba Close<br>
                            Wuse Zone 5<br>
                            Abuja, Nigeria<br>
                            <abbr title="Phone">P:</abbr> (+234) 92 918 976
                        </address>
                        <h4 class="font-alt mt0">Stay Connected</h4>
                        <a href="http://facebook.com/meednetworks" class="mr15"><i class="icon icon-facebook-squared"></i></a>
                        <a href="http://twitter.com/meednetworks" class="mr15"><i class="icon icon-twitter-squared"></i></a>
                        <a href="http://linkedin.com/company/meednetworks" class="mr15"><i class="icon icon-linkedin-squared"></i></a>
                        <a href="http://google.com/+MeedNetworks" class="mr15"><i class="icon icon-gplus-squared"></i></a>
                    </div>
                    
                    <div class="col-md-4 subscription-form">
                        <h4 class="font-alt mt0">NewsLetter</h4>
                        <form role="form" name="subscribe">
                            <div class="form-group">
                                <p class="form-control-static">Subscribe to our newsletter and stay up to date with the latest news, case studies and offers from our company!</p>
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control" id="newsletter_email" placeholder="Enter email">
                            </div>
                            <button type="submit" class="btn btn-primary btn-block">Subscribe Now</button>
                        </form>
                    </div>
                </div>                
            </div-->            
            
            <div class="footer-bottom">                
                <div class="container">
                    <div class="row">
                        <div class="col-sm-8">
                            <p class="nm text-muted"><?php echo get_theme_mod('copyright');?></p>
                        </div>
                        <?php echo get_footer_menu('footer-menu');?>
                        <!--div class="col-sm-4 text-right">
                            <a href="<?php echo  get_page_by_title('Privacy Policy')->guid;?>" data-nav class="text-white">Privacy Policy</a>
                            <span class="ml5 mr5">&#8226;</span>
                            <a href="<?php echo  get_page_by_title('Terms Of Service')->guid;?>" data-nav class="text-white">Terms of Service</a>
                            <span class="ml5 mr5">&#8226;</span>
                            <a href="<?php echo  get_page_by_title('Site Map')->guid;?>" data-nav class="text-white">Site Map</a>
                        </div-->
                    </div>
                </div>                
            </div>

            <a href="#" class="totop animation" data-toggle="waypoints totop" data-showanim="bounceIn" data-hideanim="bounceOut" data-offset="50%"><i class="icon icon-angle-up"></i></a>

        </footer>        
        
        <!--script src="//cdnjs.cloudflare.com/ajax/libs/require.js/2.1.14/require.min.js"></script-->
        <script src="//cdnjs.cloudflare.com/ajax/libs/underscore.js/1.6.0/underscore-min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>        
        <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-migrate/1.2.1/jquery-migrate.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/handlebars.js/2.0.0-alpha.4/handlebars.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.2.0/js/bootstrap.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-placeholder/2.0.7/jquery.placeholder.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.2/owl.carousel.min.js"></script>
        <!--script src="//cdnjs.cloudflare.com/ajax/libs/fastclick/1.0.2/fastclick.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/jQuery-slimScroll/1.3.1/jquery.slimscroll.min.js"></script-->
        <script src="//cdnjs.cloudflare.com/ajax/libs/unveil/1.3.0/jquery.unveil.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/waypoints/2.0.4/waypoints.min.js"></script>
        <!--script src="//cdnjs.cloudflare.com/ajax/libs/nprogress/0.1.3/nprogress.min.js"></script-->
        <script src="//cdnjs.cloudflare.com/ajax/libs/jquery.transit/0.9.9/jquery.transit.min.js"></script>
        <!--script src="js/src/libs/response.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/mustache.js/0.8.1/mustache.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/spin.js/2.0.1/spin.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/ladda-bootstrap/0.1.0/ladda.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/jquery.imagesloaded/3.0.4/jquery.imagesloaded.min.js"></script-->
        <script src="//cdnjs.cloudflare.com/ajax/libs/stellar.js/0.6.2/jquery.stellar.min.js"></script>
        <!--script src="//cdnjs.cloudflare.com/ajax/libs/jquery-sparklines/2.1.2/jquery.sparkline.min.js"></script>
        <script src="js/src/libs/jquery.counterup.min.js"></script-->
        <script src="//cdnjs.cloudflare.com/ajax/libs/moment.js/2.7.0/moment.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-mockjax/1.5.3/jquery.mockjax.js"></script>
        <script src="//maps.google.com/maps/api/js?sensor=true"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/gmaps.js/0.4.12/gmaps.min.js"></script>
        <!--script>
          define('handlebars',[],function(){return window.Handlebars});
          define('GMaps',[],function(){return window.GMaps});
        </script-->
        <script src="<?php echo get_template_directory_uri(); ?>/js/script.js"></script>        
        <script>
          (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
          (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
          m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
          })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
          ga('create', 'UA-53738162-2', 'auto');
          ga('require', 'linkid', 'linkid.js');
          ga('send', 'pageview');
        </script>
    </body>    
</html>