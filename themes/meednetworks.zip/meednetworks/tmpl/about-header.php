<?php global $header_text;?><div class="section-header text-center">
            <h2 class="section-title">
                <div class="font-alt nm"><?php echo $header_text['title'];?></div>
                <small><?php echo $header_text['text'];?></small>
            </h2>
  </div>