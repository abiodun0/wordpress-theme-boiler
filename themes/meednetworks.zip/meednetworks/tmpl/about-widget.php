<?php global $about;?><div class="col-md-4">

                        <h4 class="font-alt mt0"><?php echo $about[ 'about_title' ];?></h4>
                        <p><?php echo $about[ 'about_text' ];?></p>
                        <a data-nav href="<?php echo  get_page_by_title('About')->guid;?>" class="text-primary">Learn More</a>
 </div>