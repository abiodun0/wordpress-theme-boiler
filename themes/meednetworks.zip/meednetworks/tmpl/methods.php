<?php global $methods;?>
<div class="item">
            <h1><i class="icon <?php echo $methods['icon'];?>"></i></h1>
            <h4><?php echo $methods['title'];?></h4>
            <p><?php echo $methods['text'];?></p>
 </div>