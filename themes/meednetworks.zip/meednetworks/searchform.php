
                <form role="form" class="mb15 form-inline" method="get" action="" name="blog-search">
                    <div class="section-header section-header-bordered mb10">
                        <h4 class="section-title">
                            <p class="font-alt nm">Search</p>
                        </h4>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" name="s" placeholder="Search...">
                        <span class="input-group-btn">
                            <button class="btn btn-primary" type="button"><i class="icon icon-search"></i></button>
                        </span>
                    </div>
                </form>