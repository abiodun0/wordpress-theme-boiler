<?php global $values;?>
 <div class="row text-center">
<div class="col-sm-4">
            <h1><i class="icon <?php echo $values['icon'];?>"></i></h1>
            <h4><?php echo $values['title'];?></h4>
            <p><?php echo $values['text'];?></p>
 </div>