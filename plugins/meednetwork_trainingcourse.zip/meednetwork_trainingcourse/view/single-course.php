<?php get_header();?>

<?php   while ( have_posts() ) : the_post();
  if ( is_single() ) :
  	?>
  <?php setPostViews(get_the_ID()); ?>
  <section id="main" role="main">
  <div>
<section class="page-header page-header-block nm">
    <div class="pattern pattern9"></div>
    <div class="container pt15 pb15">
        <div class="page-header-section">
            <h4 class="title font-alt"><?php the_title();?></h4>
        </div>
        <div class="page-header-section">
            <div class="toolbar">
                <ol class="breadcrumb breadcrumb-transparent nm">
                    <li><a href="#" data-nav>Home</a></li>
                    <li class="active">Courses</li>
                </ol>
            </div>
        </div>
    </div>
</section>

<section class="section bgcolor-white">
    <div class="container">
        <div class="row">
        <div class="col-sm-9 mb15">
            <div class="panel panel-default" style="boder:0px">
                <div class="panel-body">

                    <article>
                    <h1><?php the_title();?></h1>
<?php the_content();?>
                           <h4 class="section">Request Information </h4>
                    <form class="post-form">
                    <p> Please complete the following form and a Tonex Training Specialist will contact you as soon as is possible.</p>

                            <span class="required">* Indicates required fields</span>
                            <div class="row">
                                <div class="col-sm-6">
                                    <label>Name</label>
                                    <input type="text" class="form-control">

                                    <p class="help-block">First</p>
                                </div>
                                <div class="col-sm-6">
                                    <label>&nbsp;</label>
                                    <input type="text" class="form-control">

                                    <p class="help-block">Last</p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <label>Email</label>
                                    <input type="text" class="form-control">

                                    <p class="help-block">Email</p>
                                </div>
                                <div class="col-sm-6">
                                    <label>&nbsp;</label>
                                    <input type="text" class="form-control">

                                    <p class="help-block">Confirm Email</p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <label>Company Name</label>
                                    <input type="text" class="form-control">

                                    <p class="help-block"></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <label>Title / Position</label>
                                    <input type="text" class="form-control">

                                    <p class="help-block"></p>
                                </div>

                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <label>Address</label>
                                    <input type="text" class="form-control">

                                    <p class="help-block">Street Address</p>
                                </div>

                            </div>

                            <div class="row">
                                <div class="col-sm-6">

                                    <input type="text" class="form-control">

                                    <p class="help-block">Street Address</p>
                                </div>
                                <div class="col-sm-6">

                                    <input type="text" class="form-control">

                                    <p class="help-block">State/ Province/ Region</p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">

                                    <input type="text" class="form-control">

                                    <p class="help-block">Zip / Postal Code</p>
                                </div>
                                <div class="col-sm-6">

                                    <select class="form-control">
                                        <option value="ng">Nigeria</option>
                                        <option value="gh">Ghana</option>
                                    </select>

                                    <p class="help-block">State/ Province/ Region</p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <label>Phone</label>
                                    <input type="text" class="form-control">

                                    <p class="help-block"></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <label>Fax Number</label>
                                    <input type="text" class="form-control">

                                    <p class="help-block"></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <label>How did You Learn About Us</label>
                                    <input type="text" class="form-control">

                                    <p class="help-block"></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <label>Website</label>
                                    <input type="text" class="form-control">

                                    <p class="help-block"></p>
                                </div>
                            </div>
                            <div class="form-group">

                                <label>Your Request</label>
                                <textarea rows="10" type="text" class="form-control"></textarea>

                                <p class="help-block"></p>

                            </div>
                             <div class="row">
                                <div class="col-sm-6">
                                    <label>How did You Learn About Us</label>
                                    <input type="text" class="form-control">

                                    <p class="help-block"></p>
                                </div>
                            </div>


                            <button type="submit" class="btn btn-default">Submit</button>
                        </form>
                    </article>


                </div>


            </div>


        </div>
            <div class="col-md-3 mb15">

                <div class="mb15">
                    <div class="section-header section-header-bordered mb10">
                        <h4 class="section-title">
                            <p class="font-alt nm">Popular Courses</p>
                        </h4>
                    </div>
                    <?php echo get_popular();?>
                </div>


                <!--<div class="mb15">
                    <div class="section-header section-header-bordered mb10">
                        <h4 class="section-title">
                            <p class="font-alt nm">Categories</p>
                        </h4>
                    </div>
                    <ul class="list-unstyled">
                        <li class="mb5"><i class="icon icon-angle-right text-muted mr5"></i> <a href="#">Fibre Optics</a></li>
                        <li class="mb5"><i class="icon icon-angle-right text-muted mr5"></i> <a href="#">Wireless</a></li>
                        <li class="mb5"><i class="icon icon-angle-right text-muted mr5"></i> <a href="#">Voice &amp; Video</a></li>
                        <li class="mb5"><i class="icon icon-angle-right text-muted mr5"></i> <a href="#">Network Design</a></li>
                        <li class="mb5"><i class="icon icon-angle-right text-muted mr5"></i> <a href="#">Network Audit</a></li>
                        <li class="mb5"><i class="icon icon-angle-right text-muted mr5"></i> <a href="#">Security</a></li>
                        <li class="mb5"><i class="icon icon-angle-right text-muted mr5"></i> <a href="#">Cloud Computing</a></li>
                    </ul>
                </div>-->
            </div>
        </div>
    </div>
</section>
</div>
</section>
<?php endif; endwhile;?>


<?php get_footer();?>